# Hich is an API and CLI for useful Hi-C data processing and visualization tools

## Installation

Into a fresh mamba environment
```
mamba create -n hich python=3.12 pip && mamba activate hich && pip install hich
```

With pip (requires python >= 3.12, numpy < 2.0)
```
pip install hich
```

