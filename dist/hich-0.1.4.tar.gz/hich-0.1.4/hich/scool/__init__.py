from hich.scool.scool_creator import ScoolCreator

__all__ = ['ScoolCreator']