from pydantic import BaseModel

class PairsLine(BaseModel):
    line: str
    